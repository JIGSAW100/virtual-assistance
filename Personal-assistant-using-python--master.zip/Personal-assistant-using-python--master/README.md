# Personal-assistant-using-python-
Requires to install  pyttsx3 2.71 ,  wikipedia 1.4.0  and Pyaudio. 
